# SHL_AI
Build a Grammar Scoring Engine for Voice Samples (hosted on Kaggle).
